--local widthMax = love.graphics.getWidth()
--local heightMax = love.graphics.getHeight()

--function love.draw()
--  love.graphics.setColor(62,124,64)
--  love.graphics.rectangle("fill", 0, heightMax, widthMax, heightMax/3)
--  end