function love.conf(t)
  t.window.width = 800
  t.window.heigh = 600
  t.title = "Battlecstasy"
end