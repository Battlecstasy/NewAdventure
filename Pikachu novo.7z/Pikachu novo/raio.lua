 local posY, posX, posMax, raio, variavel, count, count2, widthMax, heighMax
  
 
function love.load()
  posY = 0 -- variavel de posicao y para o raio
  posX = 400 -- variavel de posicao x do raio para ajuste das imagens no plano
  posMax = 210  -- variavel de posicao maxima em y que o raio atinge
  raio = {love.graphics.newImage("Pikachu/Raio/raio1.png"), love.graphics.newImage("Pikachu/Raio/raio2.png"), love.graphics.newImage("Pikachu/Raio/raio3.png"), love.graphics.newImage("Pikachu/Raio/raio4.png"), love.graphics.newImage("Pikachu/Raio/raio5.png")} -- vetor raio
  variavel = 1 -- variavel que serve como indice do vetor raio
  count = 0 -- contador para apos o raio atingir o chao
  count2 = 0 -- contador para animar o raio enquanto esta caindo
  widthMax = 800 --[[widthMax = love.graphics.getWidth()]] 
  heightMax = 600 --[[heightMax = love.graphics.getHeight()]]
  
  --love.graphics.setBackgroundColor(255,255,255)
  
  
end

function love.update(dt)
  
  if posY < posMax then -- fica variando entre 2 imagens do raio para dar um efeito eletrico
    posY=posY+(200*dt)
    if variavel == 1 and count2%10==0 then
      variavel = 2
    elseif variavel == 2 and count2%10==5 then
      variavel = 1
    end
    count2 = count2+1
  end
  
  if posY >= posMax then -- varia entre as 3 imagens de dissipacao do raio ao chegar chao
    if count < 15 then
      if count == 0 then -- ajusta a posicao da imagem
        posX = posX-10
      end
      variavel = 3
    elseif count >= 15 and count < 30 then
      if count == 15 then
        posX = posX-10 -- ajusta a posicao da imagem
      end
      variavel = 4
    elseif count >= 30 and count < 45  then
      variavel = 5
    elseif count >= 45 then
      variavel = 5 -- trocar para 6 depois
    end
    count = count + 1
  end
  
end

function love.draw()
  --love.window.maximize() -- aumenta a janela no maximo
  love.graphics.draw(raio[variavel], posX, posY) -- desenha o raio
  --love.graphics.setColor(62,124,64)
  --love.graphics.rectangle("fill", 0 , (2*heightMax)/3, widthMax, heightMax) -- desenha o chao verde
  --love.graphics.setColor(255,255,255) -- reseta a cor
end